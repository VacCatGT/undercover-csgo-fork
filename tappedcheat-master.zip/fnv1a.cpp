
#include "fnv1a.h"

uint32_t runtime_basis = seed;
