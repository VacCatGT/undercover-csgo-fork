# TAPPED.CC superior csgo software
![preview](https://cdn.discordapp.com/attachments/713813324323618885/727898362149470259/unknown.png)
