#include "tapped.h"

Input g_input{};;