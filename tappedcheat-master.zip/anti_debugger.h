#pragma once

class anti_debugger {
public:
	bool is_security_breached( );
}; 
extern anti_debugger g_debugger;