#pragma once

namespace LegacyMenu {
	void Draw( );
}