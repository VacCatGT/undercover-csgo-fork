#pragma once

namespace GUI::Controls {
	bool Label( const std::string& name );
}
