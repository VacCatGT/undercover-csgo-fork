#pragma once

namespace GUI::Controls {
	bool Checkbox( const std::string& name, const std::string& value, bool default_value = false, bool unsafe_feature = false );
}
