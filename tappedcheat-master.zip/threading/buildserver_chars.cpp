#include "buildserver_chars.h"

#if defined MUTINY && defined MUTINY_FRAMEWORK
//buildserver_chars_cpp
#endif