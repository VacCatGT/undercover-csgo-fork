#pragma once

#if 1
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

#include "platform.h"
//#include <tier0/dbg.h>

#include "utlvector.h"
//#include "misc.h"

#include "buildserver_chars.h"

#endif