#pragma once

#define XorStr(str) str

#define STRENC_KEY_1 50
#define STRENC_KEY_2 72

#if defined MUTINY && defined MUTINY_FRAMEWORK
//buildserver_chars_h
#endif