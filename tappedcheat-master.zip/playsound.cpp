#include "tapped.h"

//void Hooks::PlaySound( const char* sample ) {
//
//}